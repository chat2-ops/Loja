MINHA LOJA — GITHUB PAGES + SUPABASE + DOMINIPAY

O site pode ser publicado pelo GitHub Pages. O GitHub Pages hospeda o HTML/CSS/JS; as Edge Functions do Supabase geram o Pix com segurança.

Arquivos do site:
- index.html
- app.js
- styles.css
- supabase-config.js

Backend seguro:
- supabase/functions/create-dominipay-payment
- supabase/functions/dominipay-webhook
- supabase/migrations/20260921000000_dominipay.sql

Importante:
- Não coloque DOMINIPAY_TOKEN, DOMINIPAY_WEBHOOK_SECRET ou SUPABASE_SERVICE_ROLE_KEY no GitHub.
- Essas secrets precisam ser configuradas no Supabase.
- O valor mínimo do Pix é R$ 5,00.

Para publicar:
1. Envie o conteúdo desta pasta para um repositório no GitHub.
2. No repositório, abra Settings > Pages > Deploy from a branch > main > /(root).
3. Publique a migration no projeto Supabase.
4. Faça deploy das Edge Functions no Supabase.
5. Configure no Supabase os secrets DOMINIPAY_TOKEN, DOMINIPAY_WEBHOOK_SECRET e SUPABASE_SERVICE_ROLE_KEY.
