import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const rawBody = await req.text();
  const timestamp = req.headers.get('x-webhook-timestamp');
  const received = req.headers.get('x-webhook-signature');
  const secret = Deno.env.get('DOMINIPAY_WEBHOOK_SECRET');
  if (!timestamp || !received || !secret) return new Response('Missing webhook headers', { status: 400, headers: corsHeaders });
  if (!(await validSignature(`${timestamp}.${rawBody}`, received, secret))) return new Response('Invalid signature', { status: 401, headers: corsHeaders });
  try {
    const payload = JSON.parse(rawBody);
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const status = String(payload.status || 'pending');
    const update: Record<string, unknown> = { payment_status: status };
    if (status === 'approved' || status === 'paid' || status === 'completed') update.paid_at = new Date().toISOString();
    const { error } = await supabase.from('orders').update(update).eq('dominipay_payment_id', payload.id);
    if (error) return new Response('Database update failed', { status: 500, headers: corsHeaders });
    return new Response('OK', { status: 200, headers: corsHeaders });
  } catch { return new Response('Invalid payload', { status: 400, headers: corsHeaders }); }
});
async function validSignature(value: string, expectedHex: string, secret: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const digest = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value)));
  const actual = [...digest].map(byte => byte.toString(16).padStart(2, '0')).join('');
  return actual.length === expectedHex.length && [...actual].every((char, index) => char === expectedHex[index]);
}
